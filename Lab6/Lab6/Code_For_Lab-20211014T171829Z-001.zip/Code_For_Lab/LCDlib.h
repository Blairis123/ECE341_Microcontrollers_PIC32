//Lab6.h

void LCDInit(void);
//int readLCD(int);
//void busyLCD(void);
void LCDWriteChar(int, char);
//void LCDDisplayChar(char);
//void LCDWriteStr(char *);
void LCDDelay(unsigned int);
